#include <iostream>
#include <vector>
#include <algorithm>
#include <windows.h>

int binarySearch(const std::vector<int>& mas, int x, int& comps) {
    comps = 0;
    int left = 0;
    int right = static_cast<int>(mas.size()) - 1;

    while (left <= right) {
        int sredn = left + (right - left) / 2;
        
        comps++;
        if (mas[sredn] == x) {
            return sredn;
        }
        
        comps++;
        if (x < mas[sredn]) {
            right = sredn - 1;
        } else {
            left = sredn + 1;
        }
    }
    return -1;
}

int main() {
    SetConsoleOutputCP(65001);
    SetConsoleCP(65001);

    std::vector<int> data = {2, 5, 8, 12, 16, 23, 38, 56, 72, 91};
    int comps = 0;

    // Элемент в середине
    int idx1 = binarySearch(data, 16, comps);
    std::cout << "Search 16: index = " << idx1 << ", comparisons = " << comps << std::endl;

    // Элемент в конце
    int idx2 = binarySearch(data, 91, comps);
    std::cout << "Search 91: index = " << idx2 << ", comparisons = " << comps << std::endl;

    // Отсутствующий элемент
    int idx3 = binarySearch(data, 20, comps);
    std::cout << "Search 20: index = " << idx3 << ", comparisons = " << comps << std::endl;

    std::cout << "\nНажмите Enter для выхода...";
    std::cin.clear();
    std::cin.sync();
    std::cin.get();

    return 0;
}