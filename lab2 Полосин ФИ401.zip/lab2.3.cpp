#include <iostream>
#include <vector>
#include <iomanip>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <windows.h>

int linearSearch(const std::vector<int>& mas, int x) {
    int comps = 0;
    for (size_t i = 0; i < mas.size(); i++) {
        comps++;
        if (mas[i] == x) {
            break;
        }
    }
    return comps;
}

int binarySearch(const std::vector<int>& mas, int x) {
    int comps = 0;
    int left = 0;
    int right = static_cast<int>(mas.size()) - 1;

    while (left <= right) {
        int sredn = left + (right - left) / 2;
        
        comps++;
        if (mas[sredn] == x) {
            break;
        }
        
        comps++;
        if (x < mas[sredn]) {
            right = sredn - 1;
        } else {
            left = sredn + 1;
        }
    }
    return comps;
}

int main() {
    SetConsoleOutputCP(65001);
    SetConsoleCP(65001);

    std::srand(static_cast<unsigned int>(std::time(nullptr)));

    std::cout << std::left 
              << std::setw(20) << "Размер массива (N)  "
              << std::setw(45) << "Практическая сложность последовательного поиска  "
              << std::setw(40) << "Практическая сложность двоичного поиска  " 
              << std::endl;
    std::cout << std::string(105, '-') << std::endl;

    for (int N = 20; N <= 500; N += 20) {
        std::vector<int> mas(N);
        for (int i = 0; i < N; i++) {
            mas[i] = std::rand() % 1000;
        }

        std::sort(mas.begin(), mas.end());

        int target = mas[std::rand() % N];

        int linear_comps = linearSearch(mas, target);
        int binary_comps = binarySearch(mas, target);

        std::cout << std::left 
                  << std::setw(20) << N
                  << std::setw(45) << linear_comps
                  << std::setw(40) << binary_comps 
                  << std::endl;
    }

    std::cout << "\nНажмите Enter для выхода...";
    std::cin.clear();
    std::cin.sync();
    std::cin.get();

    return 0;
}