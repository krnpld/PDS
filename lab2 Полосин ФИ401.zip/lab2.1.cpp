#include <iostream>
#include <vector>
#include <windows.h>

int linearSearch(const std::vector<int>& mas, int x, int& comps) {
    comps = 0;
    for (size_t i = 0; i < mas.size(); i++) {
        comps++; 
        if (mas[i] == x) {
            return static_cast<int>(i);
        }
    }
    return -1;
}

int main() {
    SetConsoleOutputCP(65001);
    SetConsoleCP(65001);

    std::vector<int> data = {15, 3, 42, 8, 23, 4, 16};
    int comps = 0;

    // Элемент в начале
    int idx1 = linearSearch(data, 15, comps);
    std::cout << "Search 15: index = " << idx1 << ", comparisons = " << comps << std::endl;

    // Элемент в середине
    int idx2 = linearSearch(data, 8, comps);
    std::cout << "Search 8: index = " << idx2 << ", comparisons = " << comps << std::endl;

    // Отсутствующий элемент
    int idx3 = linearSearch(data, 99, comps);
    std::cout << "Search 99: index = " << idx3 << ", comparisons = " << comps << std::endl;

    std::cout << "\nНажмите Enter для выхода...";
    std::cin.clear();
    std::cin.sync();
    std::cin.get();

    return 0;
}