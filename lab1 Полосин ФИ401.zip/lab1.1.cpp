#include <iostream>
using namespace std;

const int MAX = 20;
int mas[MAX];
int n = 0;

void printMenu() {
    cout << "1 - Add element\n";
    cout << "2 - Remove element\n";
    cout << "3 - Get last element\n";
    cout << "4 - Print stack\n";
    cout << "0 - Exit\n";
    cout << "Your choice: ";
}

bool isEmpty() {
    return n == 0;
}

void print() {
    if (isEmpty()) {
        cout << "Stack is empty\n\n";
    } else {
        for (int i = 0; i < n; i++) {
            cout << mas[i] << " ";
        }
        cout << "\n\n";
    }
}

void push(int x) {
    if (n == MAX) {
        cout << "Stack is full\n\n";
    } else {
        mas[n++] = x;
        cout << "Element is added\n\n";
    }
}

void pop() {
    if (isEmpty()) {
        cout << "Stack is empty\n\n";
    } else {
        n--;
        cout << "Last element is removed\n\n";
    }
}

void last() {
    if (isEmpty()) {
        cout << "Stack is empty\n\n";
    } else {
        cout << "Last element: " << mas[n - 1] << "\n\n";
    }
}

int main()
{
    int choice;
    while (true) {
        printMenu();
        cin >> choice;
        switch (choice) {
            case 1:
                int x;
                cout << "Enter: ";
                cin >> x;
                push(x);
                break;
            case 2:
                pop();
                break;
            case 3:
                last();
                break;
            case 4:
                print();
                break;
            case 0:
                exit(EXIT_SUCCESS);
            default:
                cout << "Error\n\n";
        }
    }
    return 0;
}