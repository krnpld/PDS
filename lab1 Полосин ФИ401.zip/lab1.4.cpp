#include <iostream>
using namespace std;

struct Element {
    int item;
    bool exists;
};

const int SIZE = 10;
Element setNumbers[SIZE];

void init() {
    for (int i = 0; i < SIZE; i++) {
        setNumbers[i].exists = false;
    }
}

bool isEmpty() {
    for (int i = 0; i < SIZE; i++) {
        if (setNumbers[i].exists) return false;
    }
    return true;
}

void print() {
    if (isEmpty()) {
        cout << "Set is empty\n\n";
        return;
    }
    cout << "Set elements: ";
    for (int i = 0; i < SIZE; i++) {
        if (setNumbers[i].exists) {
            cout << setNumbers[i].item << " ";
        }
    }
    cout << "\n\n";
}

bool contains(int x) {
    for (int i = 0; i < SIZE; i++) {
        if (setNumbers[i].exists && setNumbers[i].item == x) {
            return true;
        }
    }
    return false;
}

int getEmptyPosition() {
    for (int i = 0; i < SIZE; i++) {
        if (!setNumbers[i].exists) {
            return i;
        }
    }
    return -1;
}

void add(int x) {
    if (contains(x)) {
        cout << "Element already exists in the set\n\n";
        return;
    }

    int pos = getEmptyPosition();
    if (pos != -1) {
        setNumbers[pos].item = x;
        setNumbers[pos].exists = true;
        cout << "Element added\n\n";
    } else {
        cout << "No place in set\n\n";
    }
}

void remove(int x) {
    for (int i = 0; i < SIZE; i++) {
        if (setNumbers[i].exists && setNumbers[i].item == x) {
            setNumbers[i].exists = false;
            cout << "Element removed\n\n";
            return;
        }
    }
    cout << "No such element\n\n";
}

void printMenu() {
    cout << "--- SET MENU ---\n";
    cout << "1 - Add element\n";
    cout << "2 - Delete element\n";
    cout << "3 - Check contains\n";
    cout << "4 - Print set\n";
    cout << "0 - Exit\n";
    cout << "Your choice: ";
}

int main() {
    init();
    int choice;
    while (true) {
        printMenu();
        cin >> choice;
        switch (choice) {
            case 1: {
                int x;
                cout << "Enter element to add: ";
                cin >> x;
                add(x);
                break;
            }
            case 2: {
                int x;
                cout << "Enter element to delete: ";
                cin >> x;
                remove(x);
                break;
            }
            case 3: {
                int x;
                cout << "Enter element to search: ";
                cin >> x;
                if (contains(x)) {
                    cout << "Element exists in set\n\n";
                } else {
                    cout << "Element does not exist\n\n";
                }
                break;
            }
            case 4:
                print();
                break;
            case 0:
                return 0;
            default:
                cout << "Error choice\n\n";
        }
    }
    return 0;
}