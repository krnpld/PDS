#include <iostream>
using namespace std;

const int MAX_SIZE = 10;
int contents[MAX_SIZE];
int n = 0;

bool isEmpty() {
    return n == 0;
}

void print() {
    if (isEmpty()) {
        cout << "Queue is empty\n\n";
        return;
    }
    cout << "Queue elements: ";
    for (int i = 0; i < n; i++) {
        cout << contents[i] << " ";
    }
    cout << "\n\n";
}

void enqueue(int x) {
    if (n == MAX_SIZE) {
        cout << "Queue is full\n\n";
    } else {
        contents[n] = x;
        n++;
        cout << "Element added to queue\n\n";
    }
}

void dequeue() {
    if (isEmpty()) {
        cout << "Queue is empty\n\n";
    } else {
        // Сдвиг элементов влево
        for (int i = 0; i < n - 1; i++) {
            contents[i] = contents[i + 1];
        }
        n--;
        cout << "First element removed\n\n";
    }
}

void first() {
    if (isEmpty()) {
        cout << "Queue is empty\n\n";
    } else {
        cout << "First element: " << contents[0] << "\n\n";
    }
}

void printMenu() {
    cout << "--- QUEUE MENU ---\n";
    cout << "1 - Enqueue\n";
    cout << "2 - Dequeue\n";
    cout << "3 - Get First\n";
    cout << "4 - Print Queue\n";
    cout << "0 - Exit\n";
    cout << "Your choice: ";
}

int main() {
    int choice;
    while (true) {
        printMenu();
        cin >> choice;
        switch (choice) {
            case 1: {
                int x;
                cout << "Enter element: ";
                cin >> x;
                enqueue(x);
                break;
            }
            case 2:
                dequeue();
                break;
            case 3:
                first();
                break;
            case 4:
                print();
                break;
            case 0:
                return 0;
            default:
                cout << "Error choice\n\n";
        }
    }
    return 0;
}