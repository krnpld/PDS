#include <iostream>
using namespace std;

const int MAX_SIZE = 10;
double contents[MAX_SIZE];
int n = 0;

bool isEmpty() {
    return n == 0;
}

void print() {
    if (isEmpty()) {
        cout << "List is empty\n\n";
        return;
    }
    cout << "List elements: ";
    for (int i = 0; i < n; i++) {
        cout << contents[i] << " ";
    }
    cout << "\n\n";
}

void insert(double x, int pos) {
    if (n == MAX_SIZE) {
        cout << "List is full\n\n";
    } else if (pos < 0 || pos > n) {
        cout << "Incorrect index\n\n";
    } else {
        // Сдвиг элементов вправо
        for (int i = n - 1; i >= pos; i--) {
            contents[i + 1] = contents[i];
        }
        contents[pos] = x;
        n++;
        cout << "Element inserted\n\n";
    }
}

int indexOf(double x) {
    for (int i = 0; i < n; i++) {
        if (contents[i] == x) {
            return i;
        }
    }
    return -1;
}

void remove(int pos) {
    if (pos < 0 || pos >= n) {
        cout << "Incorrect index or element not found\n\n";
    } else {
        // Сдвиг элементов влево
        for (int i = pos; i < n - 1; i++) {
            contents[i] = contents[i + 1];
        }
        n--;
        cout << "Element removed\n\n";
    }
}

void printMenu() {
    cout << "--- LIST MENU ---\n";
    cout << "1 - Insert element\n";
    cout << "2 - Remove element by index\n";
    cout << "3 - Find index of element\n";
    cout << "4 - Print list\n";
    cout << "0 - Exit\n";
    cout << "Your choice: ";
}

int main() {
    int choice;
    while (true) {
        printMenu();
        cin >> choice;
        switch (choice) {
            case 1: {
                double val;
                int pos;
                cout << "Enter value: ";
                cin >> val;
                cout << "Enter position (0 to " << n << "): ";
                cin >> pos;
                insert(val, pos);
                break;
            }
            case 2: {
                int pos;
                cout << "Enter index to remove: ";
                cin >> pos;
                remove(pos);
                break;
            }
            case 3: {
                double val;
                cout << "Enter value to find: ";
                cin >> val;
                int index = indexOf(val);
                if (index != -1) {
                    cout << "Element found at index: " << index << "\n\n";
                } else {
                    cout << "Element not found\n\n";
                }
                break;
            }
            case 4:
                print();
                break;
            case 0:
                return 0;
            default:
                cout << "Error choice\n\n";
        }
    }
    return 0;
}